package com.springbatch.processadorvalidacaojob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessadorValidacaoJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
