package com.springbatch.arquivomultiplosformatos.dominio;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Transacao {
	private String id;
	private String descricao;
	private BigDecimal valor;
	private List<Transacao2> listaTransacao2 = new ArrayList<>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public List<Transacao2> getListaTransacao2() {
		return listaTransacao2;
	}

	public void setListaTransacao2(List<Transacao2> listaTransacao2) {
		this.listaTransacao2 = listaTransacao2;
	}

	@Override
	public String toString() {
		return "Transacao{" + "id='" + id + "'" + ", descricao='" + descricao + "'" + ", valor='" + valor + "'" +
				(listaTransacao2.isEmpty() ? "" : ", transacoes=" + listaTransacao2)+ '}';
	}
}
