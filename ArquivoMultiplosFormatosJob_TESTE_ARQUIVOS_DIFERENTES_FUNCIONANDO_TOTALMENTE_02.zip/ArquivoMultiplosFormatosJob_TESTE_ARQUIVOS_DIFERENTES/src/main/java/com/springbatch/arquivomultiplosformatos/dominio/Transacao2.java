package com.springbatch.arquivomultiplosformatos.dominio;

public class Transacao2 {
	
	private String un; 
	private String dos;
	private String tres;
	private String unPassito;

	public String getUn() {
		return un;
	}

	public void setUn(String un) {
		this.un = un;
	}

	public String getDos() {
		return dos;
	}

	public void setDos(String dos) {
		this.dos = dos;
	}

	public String getTres() {
		return tres;
	}

	public void setTres(String tres) {
		this.tres = tres;
	}

	public String getUnPassito() {
		return unPassito;
	}

	public void setUnPassito(String unPassito) {
		this.unPassito = unPassito;
	}

	@Override
	public String toString() {
		return "Transacao2{" + "un='" + un + "'" + ", dos='" + dos + "'" + ", tres='" + tres + "'" + ", unPassito='" + unPassito + '}';
	}
}
