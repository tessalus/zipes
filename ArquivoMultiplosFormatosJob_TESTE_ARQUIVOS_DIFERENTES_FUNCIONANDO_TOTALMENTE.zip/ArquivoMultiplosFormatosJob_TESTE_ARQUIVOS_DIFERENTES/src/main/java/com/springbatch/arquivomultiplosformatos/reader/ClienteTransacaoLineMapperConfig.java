package com.springbatch.arquivomultiplosformatos.reader;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.springbatch.arquivomultiplosformatos.dominio.Cliente;
import com.springbatch.arquivomultiplosformatos.dominio.Transacao;

@Configuration
public class ClienteTransacaoLineMapperConfig {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public PatternMatchingCompositeLineMapper lineMapper() {

		PatternMatchingCompositeLineMapper lineMapper = new PatternMatchingCompositeLineMapper<>();
		lineMapper.setTokenizers(tokenizers());
		lineMapper.setFieldSetMappers(fildSetMappers());
		
		return lineMapper;
	}

	@SuppressWarnings("rawtypes")
	private Map<String, FieldSetMapper> fildSetMappers() {

		Map<String, FieldSetMapper> fieldSetMapers = new HashMap<>();
		fieldSetMapers.put("0*", fieldSetMaper(Cliente.class));
		fieldSetMapers.put("1*", fieldSetMaper(Transacao.class));
		
		return fieldSetMapers;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private FieldSetMapper fieldSetMaper(Class classe) {

		BeanWrapperFieldSetMapper fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(classe);		
		
		return fieldSetMapper;
	}

	private Map<String, LineTokenizer> tokenizers() {

		Map<String, LineTokenizer> tokenizers = new HashMap<>();
		tokenizers.put("0*", clientLineTokenizer());
		tokenizers.put("1*", transacaoLineTokenizer());
		
		return tokenizers;
	}

	private LineTokenizer clientLineTokenizer() {

		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setNames("nome", "sobrenome", "idade", "email");
		lineTokenizer.setIncludedFields(1, 2, 3, 4);
		
		return lineTokenizer;
	}
	
	private LineTokenizer transacaoLineTokenizer() {

		FixedLengthTokenizer fixedLengthTokenizer = new FixedLengthTokenizer();
		fixedLengthTokenizer.setNames("id", "descricao", "valor");
		fixedLengthTokenizer.setColumns(new Range[] {new Range(2, 5), new Range(6, 21), new Range(22, 28)});
		
		return fixedLengthTokenizer;
	}	
	
}
