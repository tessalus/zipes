package com.springbatch.arquivomultiplosformatos.reader;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.ResourceAwareItemReaderItemStream;
import org.springframework.core.io.Resource;

import com.springbatch.arquivomultiplosformatos.dominio.Cliente;
import com.springbatch.arquivomultiplosformatos.dominio.Transacao;

public class ArquivoClienteTransacaoReader implements ItemStreamReader<Object>, ResourceAwareItemReaderItemStream<Object> {

	private Object objetoAtual;
	private FlatFileItemReader<Object> delegate;

	public ArquivoClienteTransacaoReader(FlatFileItemReader<Object> delegate) {
		this.delegate = delegate;
	}

	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		delegate.open(executionContext);
		
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		delegate.update(executionContext);
		
	}

	@Override
	public void close() throws ItemStreamException {
		delegate.close();		
	}

	@Override
	public Object read() throws Exception {
		 
		Object retorno = null;
		
		if(objetoAtual == null) {			
			peek();
		}
					
		if(objetoAtual instanceof Cliente) {	
			Cliente cliente = (Cliente) objetoAtual;
			retorno = cliente;
		} else if(objetoAtual instanceof Transacao) {
			Transacao transacao = (Transacao) objetoAtual;			
			retorno = transacao;
		}
			
		objetoAtual = null;
		
		return retorno;
	}

	private Object peek() throws Exception {

		objetoAtual = delegate.read();
		
		return objetoAtual;
	}

	@Override
	public void setResource(Resource resource) {
		delegate.setResource(resource);		
	}

}
